package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.stripe.StripePaymentType
import com.example.ui.components.AddEditSubscriptionDialog
import com.example.ui.components.AdvancedRemindersDialog
import com.example.ui.components.AiCancellationDialog
import com.example.ui.components.AiCancellationModeSelectDialog
import com.example.ui.components.AppNavTab
import com.example.ui.components.BiometricLockScreen
import com.example.ui.components.EventLogDialog
import com.example.ui.components.FilterChipRow
import com.example.ui.components.ProminentGreenBarChartCard
import com.example.ui.components.RewardedAdPlayerDialog
import com.example.ui.components.SmartScanDialog
import com.example.ui.components.SocialShareDialog
import com.example.ui.components.SpendSummaryCard
import com.example.ui.components.StandardBannerAdCard
import com.example.ui.components.StripePaymentSheetDialog
import com.example.ui.components.SubKillerBottomNavBar
import com.example.ui.components.SubscriptionItemCard
import com.example.ui.components.SubscriptionSearchBar
import com.example.ui.components.TopHeaderBar
import com.example.ui.components.UtilityBillCard
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.FinanceBorder
import com.example.ui.theme.FinanceCard
import com.example.ui.theme.FinanceObsidian
import com.example.ui.theme.LescoOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ActiveDialog
import com.example.ui.viewmodel.DueDateRange
import com.example.ui.viewmodel.SubTrackViewModel
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DashboardScreen(
    viewModel: SubTrackViewModel,
    modifier: Modifier = Modifier
) {
    val allSubscriptions by viewModel.allSubscriptions.collectAsState()
    val filteredSubscriptions by viewModel.filteredSubscriptions.collectAsState()
    val summary by viewModel.summary.collectAsState()
    val currentCurrency by viewModel.selectedCurrency.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedDueDateRange by viewModel.selectedDueDateRange.collectAsState()
    val activeDialog by viewModel.activeDialog.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val isPaymentProcessing by viewModel.isPaymentProcessing.collectAsState()
    val isScanProcessing by viewModel.isScanProcessing.collectAsState()
    val uiNotice by viewModel.uiNotice.collectAsState()
    val eventLogs by viewModel.allEventLogs.collectAsState()
    val isBiometricLocked by viewModel.isBiometricLocked.collectAsState()
    val biometricError by viewModel.biometricError.collectAsState()

    var currentTab by remember { mutableStateOf(AppNavTab.HOME) }
    var showEventLogsDialog by remember { mutableStateOf(false) }
    val isPremium = userProfile?.isPremium ?: false
    val isRemindersActive = userProfile?.isAdvancedRemindersActive ?: false

    val snackbarHostState = remember { SnackbarHostState() }
    val utilitiesList = allSubscriptions.filter { it.isUtility }
    val regularSubsList = allSubscriptions.filter { !it.isUtility }

    val liveMonthlySpendUsd = remember(allSubscriptions) {
        allSubscriptions.filter { it.status == "active" || it.status == "negotiating" }.sumOf { item ->
            val sourceCur = if (item.currency.equals("PKR", ignoreCase = true)) com.example.data.model.CurrencyCode.PKR else com.example.data.model.CurrencyCode.USD
            com.example.data.model.CurrencyManager.convert(item.amount, sourceCur, com.example.data.model.CurrencyCode.USD)
        }
    }
    val liveSavedUsd = userProfile?.totalSaved ?: 0.0

    LaunchedEffect(uiNotice) {
        uiNotice?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearNotice()
        }
    }

    val context = LocalContext.current
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.triggerMonthlySummaryNotification(context)
    }

    val onPushMonthlyNotification = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                viewModel.triggerMonthlySummaryNotification(context)
            } else {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            viewModel.triggerMonthlySummaryNotification(context)
        }
    }

    if (isBiometricLocked) {
        val activity = context as? androidx.fragment.app.FragmentActivity
        BiometricLockScreen(
            onTriggerBiometric = {
                if (activity != null) {
                    viewModel.triggerBiometricPrompt(activity)
                } else {
                    viewModel.unlockAppWithSecurityCode()
                }
            },
            onBypassWithPasscode = {
                viewModel.unlockAppWithSecurityCode()
            },
            errorMessage = biometricError
        )
        return
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(FinanceObsidian),
        containerColor = FinanceObsidian,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            SubKillerBottomNavBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        },
        floatingActionButton = {
            AnimatedVisibility(
                visible = currentTab == AppNavTab.HOME || currentTab == AppNavTab.SUBSCRIPTIONS,
                enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
            ) {
                FloatingActionButton(
                    onClick = { viewModel.openDialog(ActiveDialog.EditSubscription(isUtilityDefault = false)) },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.testTag("fab_add_item")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Item", modifier = Modifier.size(24.dp))
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // ==========================================
            // ANIMATION CORE: BEAUTIFUL CROSSFADE TABS
            // ==========================================
            Crossfade(
                targetState = currentTab,
                animationSpec = tween(durationMillis = 400),
                label = "Tab_Transition"
            ) { tab ->
                when (tab) {
                    AppNavTab.HOME -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("home_screen_content"),
                            contentPadding = PaddingValues(bottom = 90.dp)
                        ) {
                            item {
                                TopHeaderBar(
                                    currentCurrency = currentCurrency,
                                    isPremium = isPremium,
                                    onToggleCurrency = { viewModel.toggleCurrency() },
                                    onOpenSmartScan = { viewModel.openDialog(ActiveDialog.SmartScan) },
                                    onOpenSocialShare = { viewModel.openDialog(ActiveDialog.SocialShare) },
                                    onLockBiometrically = { viewModel.lockAppBiometrically() }
                                )
                            }

                            item {
                                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).animateContentSize()) {
                                    ProminentGreenBarChartCard(
                                        summary = summary,
                                        currentCurrency = currentCurrency,
                                        activeMonthlySpendUsd = liveMonthlySpendUsd,
                                        cumulativeSavedUsd = liveSavedUsd
                                    )
                                }
                            }

                            item {
                                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).animateContentSize()) {
                                    SpendSummaryCard(
                                        summary = summary,
                                        currentCurrency = currentCurrency,
                                        onToggleCurrency = { viewModel.toggleCurrency() }
                                    )
                                }
                            }

                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                        .animateContentSize(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(FinanceCard)
                                            .border(1.dp, LescoOrange.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                            .clickable { viewModel.openDialog(ActiveDialog.EditSubscription(isUtilityDefault = true)) }
                                            .padding(vertical = 10.dp, horizontal = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = LescoOrange, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "+ Utility", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(FinanceCard)
                                            .border(1.dp, CyanAccent.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                            .clickable { viewModel.openDialog(ActiveDialog.EditSubscription(isUtilityDefault = false)) }
                                            .padding(vertical = 10.dp, horizontal = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "+ Sub", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1.1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(FinanceCard)
                                            .border(1.dp, if (isRemindersActive) EmeraldGlow else CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                            .clickable { viewModel.openDialog(ActiveDialog.AdvancedReminders) }
                                            .padding(vertical = 10.dp, horizontal = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = "Alerts", tint = if (isRemindersActive) EmeraldGlow else CyanAccent, modifier = Modifier.size(15.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "Reminders", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = if (isRemindersActive) EmeraldGlow else TextPrimary)
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(FinanceCard)
                                            .border(1.dp, FinanceBorder, RoundedCornerShape(12.dp))
                                            .clickable { showEventLogsDialog = true }
                                            .padding(horizontal = 10.dp, vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(imageVector = Icons.Default.History, contentDescription = "History", tint = EmeraldGlow, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            // ANIMATED EMPTY STATE
                            if (allSubscriptions.isEmpty()) {
                                item {
                                    AnimatedVisibility(
                                        visible = true,
                                        enter = fadeIn(animationSpec = tween(500)) + slideInVertically(initialOffsetY = { 50 }),
                                        exit = fadeOut()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                                .clip(RoundedCornerShape(18.dp))
                                                .background(FinanceCard)
                                                .border(1.dp, EmeraldPrimary.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
                                                .padding(22.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                                Box(modifier = Modifier.size(54.dp).clip(CircleShape).background(EmeraldPrimary.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                                                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = EmeraldGlow, modifier = Modifier.size(28.dp))
                                                }
                                                Spacer(modifier = Modifier.height(12.dp))
                                                Text(text = "No active subscriptions.", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(text = "Add your first bill below.", style = MaterialTheme.typography.bodySmall, color = TextSecondary, textAlign = TextAlign.Center)
                                                Spacer(modifier = Modifier.height(16.dp))

                                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Button(
                                                        onClick = { viewModel.openDialog(ActiveDialog.EditSubscription(isUtilityDefault = true)) },
                                                        modifier = Modifier.weight(1f).height(44.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = Color.White),
                                                        shape = RoundedCornerShape(10.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(text = "Add First Bill", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                                                    }
                                                    Button(
                                                        onClick = { viewModel.openDialog(ActiveDialog.SmartScan) },
                                                        modifier = Modifier.weight(1f).height(44.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color(0xFF082F49)),
                                                        shape = RoundedCornerShape(10.dp)
                                                    ) {
                                                        Icon(imageVector = Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(text = "Start Scan", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                item {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp)
                                            .animateContentSize(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = LescoOrange, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(text = "UTILITY BILLS (LOCAL)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp), color = TextPrimary)
                                        }
                                        Text(text = "${utilitiesList.size} bills", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    }
                                }

                                // ANIMATED LIST ITEMS FOR UTILITIES
                                items(utilitiesList, key = { it.id }) { bill ->
                                    Box(modifier = Modifier.animateItemPlacement(animationSpec = tween(300)).padding(horizontal = 16.dp, vertical = 5.dp)) {
                                        UtilityBillCard(
                                            bill = bill,
                                            currentCurrency = currentCurrency,
                                            onTogglePaid = { id, currentPaid -> viewModel.toggleBillPaid(id, currentPaid) },
                                            onAiCancelOrAudit = { viewModel.openDialog(ActiveDialog.AiCancellationModeSelect(it)) },
                                            onDelete = { viewModel.deleteSubscription(it) },
                                            onRemindMe = { viewModel.triggerItemReminder(context, it) },
                                            onClick = { viewModel.openDialog(ActiveDialog.EditSubscription(subscription = it, isUtilityDefault = it.isUtility)) }
                                        )
                                    }
                                }

                                item {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 4.dp)
                                            .animateContentSize(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(text = "ACTIVE SUBSCRIPTIONS", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp), color = TextPrimary)
                                        }
                                        Text(text = "${regularSubsList.size} services", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                    }
                                }

                                // ANIMATED LIST ITEMS FOR SUBSCRIPTIONS
                                items(regularSubsList, key = { it.id }) { sub ->
                                    Box(modifier = Modifier.animateItemPlacement(animationSpec = tween(300)).padding(horizontal = 16.dp, vertical = 5.dp)) {
                                        SubscriptionItemCard(
                                            subscription = sub,
                                            currentCurrency = currentCurrency,
                                            onAiCancel = { viewModel.openDialog(ActiveDialog.AiCancellationModeSelect(it)) },
                                            onDelete = { viewModel.deleteSubscription(it) },
                                            onRemindMe = { viewModel.triggerItemReminder(context, it) },
                                            onClick = { viewModel.openDialog(ActiveDialog.EditSubscription(subscription = it, isUtilityDefault = it.isUtility)) }
                                        )
                                    }
                                }
                            }

                            if (!isRemindersActive) {
                                item {
                                    StandardBannerAdCard(
                                        onUpgradeClicked = { viewModel.openDialog(ActiveDialog.AdvancedReminders) },
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                                    )
                                }
                            }
                        }
                    }

                    AppNavTab.SUBSCRIPTIONS -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("subscriptions_screen_content"),
                            contentPadding = PaddingValues(bottom = 90.dp)
                        ) {
                            item {
                                TopHeaderBar(
                                    currentCurrency = currentCurrency,
                                    isPremium = isPremium,
                                    onToggleCurrency = { viewModel.toggleCurrency() },
                                    onOpenSmartScan = { viewModel.openDialog(ActiveDialog.SmartScan) },
                                    onOpenSocialShare = { viewModel.openDialog(ActiveDialog.SocialShare) },
                                    onLockBiometrically = { viewModel.lockAppBiometrically() }
                                )
                            }

                            item {
                                Box(modifier = Modifier.animateContentSize()) {
                                    SubscriptionSearchBar(
                                        searchQuery = searchQuery,
                                        onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                                        selectedDueDateRange = selectedDueDateRange,
                                        onDueDateRangeSelected = { viewModel.setDueDateRange(it) },
                                        onClearFilters = { viewModel.clearSearchAndDateFilters() },
                                        matchingCount = filteredSubscriptions.size,
                                        totalCount = allSubscriptions.size
                                    )
                                }
                            }

                            item {
                                Box(modifier = Modifier.animateContentSize()) {
                                    FilterChipRow(
                                        selectedFilter = selectedFilter,
                                        onSelectFilter = { viewModel.setFilter(it) }
                                    )
                                }
                            }

                            if (filteredSubscriptions.isEmpty()) {
                                item {
                                    AnimatedVisibility(
                                        visible = true,
                                        enter = fadeIn() + slideInVertically(initialOffsetY = { 20 })
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp, vertical = 24.dp)
                                                .clip(RoundedCornerShape(16.dp))
                                                .background(FinanceCard)
                                                .border(1.dp, FinanceBorder, RoundedCornerShape(16.dp))
                                                .padding(20.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                val hasSearchOrDateFilter = searchQuery.isNotBlank() || selectedDueDateRange != DueDateRange.ALL
                                                Icon(
                                                    imageVector = if (hasSearchOrDateFilter) Icons.Default.SearchOff else Icons.Default.Info,
                                                    contentDescription = null,
                                                    tint = if (hasSearchOrDateFilter) CyanAccent else TextMuted,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text(
                                                    text = if (hasSearchOrDateFilter) "No matching subscriptions found" else "No items in this category",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = TextPrimary
                                                )
                                                if (hasSearchOrDateFilter) {
                                                    Spacer(modifier = Modifier.height(12.dp))
                                                    OutlinedButton(onClick = { viewModel.clearSearchAndDateFilters() }) {
                                                        Text("Reset Search & Filters", color = CyanAccent)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            items(filteredSubscriptions, key = { it.id }) { item ->
                                Box(modifier = Modifier.animateItemPlacement(animationSpec = tween(300)).padding(horizontal = 16.dp, vertical = 5.dp)) {
                                    if (item.isUtility) {
                                        UtilityBillCard(
                                            bill = item,
                                            currentCurrency = currentCurrency,
                                            onTogglePaid = { id, currentPaid -> viewModel.toggleBillPaid(id, currentPaid) },
                                            onAiCancelOrAudit = { viewModel.openDialog(ActiveDialog.AiCancellationModeSelect(it)) },
                                            onDelete = { viewModel.deleteSubscription(it) },
                                            onRemindMe = { viewModel.triggerItemReminder(context, it) },
                                            onClick = { viewModel.openDialog(ActiveDialog.EditSubscription(subscription = it, isUtilityDefault = it.isUtility)) }
                                        )
                                    } else {
                                        SubscriptionItemCard(
                                            subscription = item,
                                            currentCurrency = currentCurrency,
                                            onAiCancel = { viewModel.openDialog(ActiveDialog.AiCancellationModeSelect(it)) },
                                            onDelete = { viewModel.deleteSubscription(it) },
                                            onRemindMe = { viewModel.triggerItemReminder(context, it) },
                                            onClick = { viewModel.openDialog(ActiveDialog.EditSubscription(subscription = it, isUtilityDefault = it.isUtility)) }
                                        )
                                    }
                                }
                            }

                            if (!isRemindersActive) {
                                item {
                                    StandardBannerAdCard(
                                        onUpgradeClicked = { viewModel.openDialog(ActiveDialog.AdvancedReminders) },
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }

                    AppNavTab.INSIGHTS -> {
                        InsightsScreen(
                            summary = summary,
                            subscriptions = allSubscriptions,
                            currentCurrency = currentCurrency
                        )
                    }

                    AppNavTab.PROFILE -> {
                        ProfileScreen(
                            userProfile = userProfile,
                            currentCurrency = currentCurrency,
                            isBiometricEnabled = isBiometricLocked, // Using ViewModel state mapping
                            onToggleBiometric = { /* mapped via ViewModel */ },
                            onToggleCurrency = { viewModel.toggleCurrency() },
                            onUpgradeRequested = {
                                viewModel.openDialog(
                                    ActiveDialog.StripeCheckout(
                                        paymentType = StripePaymentType.SMART_SCAN_ONE_TIME,
                                        amount = 2.99,
                                        title = "Smart Scan Pro (Lifetime)",
                                        description = "LESCO & K-Electric OCR Bill Parser   Zero Ads"
                                    )
                                )
                            },
                            onOpenSocialShare = { viewModel.openDialog(ActiveDialog.SocialShare) },
                            onOpenEventLogs = { showEventLogsDialog = true },
                            onOpenSmartScan = { viewModel.openDialog(ActiveDialog.SmartScan) },
                            onOpenAdvancedReminders = { viewModel.openDialog(ActiveDialog.AdvancedReminders) },
                            onSignInGoogle = { viewModel.signInWithGoogle() },
                            onSignOutGoogle = { viewModel.signOutGoogle() },
                            onClearSampleData = { viewModel.clearSampleData() },
                            onPushMonthlySummaryNotification = onPushMonthlyNotification,
                            onExportData = { viewModel.exportDataToClipboard(context) },
                            onLockBiometrically = { viewModel.lockAppBiometrically() }
                        )
                    }
                }
            }
        }
    }

    // Modal Overlays (All exactly intact from previous features)
    when (val dialog = activeDialog) {
        is ActiveDialog.AiCancellationModeSelect -> AiCancellationModeSelectDialog(dialog.subscription, currentCurrency, { annual, fee -> viewModel.openDialog(ActiveDialog.StripeCheckout(StripePaymentType.AI_CANCELLATION_SUCCESS_FEE, fee, "10% Success Fee", "Savings: $annual", dialog.subscription)) }, { viewModel.openDialog(ActiveDialog.RewardedAdPlayer(dialog.subscription)) }, { viewModel.closeDialog() })
        is ActiveDialog.RewardedAdPlayer -> RewardedAdPlayerDialog(dialog.subscription, { viewModel.completeRewardedAdsForCancellation(dialog.subscription) }, { viewModel.closeDialog() })
        is ActiveDialog.StripeCheckout -> StripePaymentSheetDialog(dialog.paymentType, dialog.amount, dialog.title, dialog.description, isPaymentProcessing, { card -> viewModel.processStripeGatewayPayment(card, dialog.paymentType, dialog.amount, dialog.subscription) { viewModel.closeDialog() } }, { viewModel.closeDialog() })
        is ActiveDialog.AdvancedReminders -> AdvancedRemindersDialog(isRemindersActive, { viewModel.openDialog(ActiveDialog.StripeCheckout(StripePaymentType.ADVANCED_REMINDERS_SUBSCRIPTION, 2.99, "Advanced Reminders", "Recurring $2.99/mo")) }, { viewModel.cancelAdvancedReminders(); viewModel.closeDialog() }, onPushMonthlyNotification, { viewModel.triggerWorkManagerCheck(context) }, { viewModel.closeDialog() })
        is ActiveDialog.AiCancellation -> AiCancellationDialog(dialog.subscription, dialog.pregeneratedRequest, userProfile?.email ?: "", userProfile?.name ?: "", { r, t -> viewModel.triggerAiCancellation(dialog.subscription, r, t) { viewModel.closeDialog() } }, { viewModel.updateCancellationStatus(dialog.pregeneratedRequest?.id ?: "", dialog.subscription.id, "cancelled", ""); viewModel.closeDialog() }, { viewModel.closeDialog() })
        is ActiveDialog.PremiumUpgrade -> StripePaymentSheetDialog(StripePaymentType.SMART_SCAN_ONE_TIME, 2.99, "Smart Scan Pro", "Lifetime Unlock", isPaymentProcessing, { card -> viewModel.processStripeGatewayPayment(card, StripePaymentType.SMART_SCAN_ONE_TIME, 2.99, null) { viewModel.closeDialog() } }, { viewModel.closeDialog() })
        is ActiveDialog.SmartScan -> SmartScanDialog(isPremium, isScanProcessing, { k -> viewModel.runSmartScanSimulation(k) { viewModel.closeDialog() } }, { viewModel.openDialog(ActiveDialog.PremiumUpgrade) }, { viewModel.closeDialog() })
        is ActiveDialog.SocialShare -> SocialShareDialog(summary, currentCurrency, isPremium, { viewModel.closeDialog() })
        is ActiveDialog.EditSubscription -> AddEditSubscriptionDialog(dialog.subscription, dialog.isUtilityDefault, currentCurrency, { id, n, c, p, isU, uT, cN, a, curr, cyc, nD, e, nts, unts -> viewModel.saveSubscription(id, n, c, p, isU, uT, cN, a, curr, cyc, nD, e, nts, unts) }, { viewModel.closeDialog() })
        else -> { /* No dialog */ }
    }

    if (showEventLogsDialog) {
        EventLogDialog(logs = eventLogs, onDismiss = { showEventLogsDialog = false })
    }
}