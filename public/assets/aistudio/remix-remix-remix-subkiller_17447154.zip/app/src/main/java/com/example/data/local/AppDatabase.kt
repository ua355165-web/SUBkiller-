package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.CancellationRequestEntity
import com.example.data.model.EventLogEntity
import com.example.data.model.SubscriptionEntity
import com.example.data.model.UserProfileEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SubscriptionEntity::class,
        CancellationRequestEntity::class,
        EventLogEntity::class,
        UserProfileEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun cancellationDao(): CancellationDao
    abstract fun eventLogDao(): EventLogDao
    abstract fun userProfileDao(): UserProfileDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "subtrack_finance.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        ensureInitialProfile(database)
                    }
                }
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        // Purge any stale sample data to guarantee only live real user data is displayed
                        database.subscriptionDao().clearSampleData()
                    }
                }
            }
        }

        private suspend fun ensureInitialProfile(database: AppDatabase) {
            val profileDao = database.userProfileDao()
            val existing = profileDao.getUserProfile()
            if (existing == null) {
                profileDao.insert(
                    UserProfileEntity(
                        id = "primary_user",
                        email = "ua355165@gmail.com",
                        name = "Hamza R.",
                        preferredCurrency = "USD",
                        isPremium = false,
                        scansPerformed = 0,
                        totalSaved = 0.0
                    )
                )
            }
        }
    }
}
